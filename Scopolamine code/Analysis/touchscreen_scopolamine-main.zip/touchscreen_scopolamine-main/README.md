# touchscreen_scopolamine
Analysis of scopolamine administration on performance in a simple discrimination learning task
